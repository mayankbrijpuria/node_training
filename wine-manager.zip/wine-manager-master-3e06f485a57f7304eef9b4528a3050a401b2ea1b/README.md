# Wine Manager

In this project we will be creating a wine manager application using the front end created for you here. Your job is to make the functionality work as follows:

- Display all wines on index.html.
- When the form in the add wine modal is filled out and submitted, add the wine and display the updates wines on the index page.
- Show an edit form for a specific wine when the edit button is clicked. The template for this is edit.html.
- **Bonus:** Implement a delete button on the edit page.